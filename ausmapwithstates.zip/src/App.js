import React from "react"
import MapView from "./components/MapView"
import Axios from "axios"



function App() {
    const [hasFetched, setHasFetched] = React.useState(false);


    let Sydney={
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "properties": {},
                
            }
        ]
    };

    const fetchData = async () => {
        try {
        const res = await Axios.get("https://nominatim.openstreetmap.org/search.php?q=Sydney+Australia&polygon_geojson=1&format=json");  
        Sydney.features[0].geometry = res.data[0].geojson;
        Sydney.features[0].id = 0;
        setHasFetched(true);
            
        } catch (error) {
            console.log(error);
        }
    }

    React.useEffect(()=>{
        fetchData()
      },[hasFetched]);


  return (<>
        <MapView sydney={Sydney}/>

    {/* {hasFetched ? <div className="App">
        
        <MapView Sydney={Sydney}/>
          
    </div>:<></>} */}
  </>
  );
}

export default App;
